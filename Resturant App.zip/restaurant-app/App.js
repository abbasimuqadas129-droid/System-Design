import React, { createContext, useState, useContext } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList, 
  StyleSheet, Alert, ScrollView, SafeAreaView, StatusBar
} from 'react-native';

// ======================== CONTEXT ========================
const AppContext = createContext();

const initialMenu = [
  { id: '1', name: 'Margherita Pizza', price: 3637, description: 'Classic cheese & tomato', image: '🍕' },
  { id: '2', name: 'Caesar Salad', price: 2517, description: 'Fresh romaine with parmesan', image: '🥗' },
  { id: '3', name: 'Spaghetti Carbonara', price: 4197, description: 'Creamy pasta with bacon', image: '🍝' },
  { id: '4', name: 'Cheeseburger', price: 3077, description: 'Beef patty with cheddar', image: '🍔' },
  { id: '5', name: 'Chocolate Lava Cake', price: 1957, description: 'Warm chocolate cake', image: '🍰' },
];

const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [menuItems, setMenuItems] = useState(initialMenu);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [currentScreen, setCurrentScreen] = useState('login');
  const [currentTab, setCurrentTab] = useState('menu');

  const loginAsCustomer = (name) => {
    setUser({ id: 'cust1', name, role: 'customer', email: `${name}@example.com` });
    setCurrentScreen('customer');
    setCurrentTab('menu');
  };
  
  const loginAsManager = () => {
    setUser({ id: 'mgr1', name: 'John Manager', role: 'manager', email: 'manager@restaurant.com' });
    setCurrentScreen('manager');
    setCurrentTab('dashboard');
  };
  
  const logout = () => { 
    setUser(null); 
    setCart([]); 
    setCurrentScreen('login');
  };

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };
  
  const removeFromCart = (itemId) => {
    setCart(prev => prev.filter(i => i.id !== itemId));
  };
  
  const updateQuantity = (itemId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    setCart(prev => prev.map(i => i.id === itemId ? { ...i, quantity } : i));
  };
  
  const clearCart = () => setCart([]);

  const placeOrder = () => {
    if (cart.length === 0) return null;
    const total = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
    const newOrder = { 
      id: Date.now().toString(), 
      customerName: user.name, 
      items: [...cart], 
      total: total, 
      status: 'Received', 
      date: new Date().toLocaleString()
    };
    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    Alert.alert('Success', 'Order placed successfully!');
    return newOrder;
  };

  const addReservation = (data) => {
    const newRes = { 
      id: Date.now().toString(), 
      customerName: user.name, 
      ...data, 
      status: 'Pending'
    };
    setReservations(prev => [newRes, ...prev]);
    Alert.alert('Success', 'Table booked successfully!');
    return newRes;
  };
  
  const updateReservationStatus = (resId, newStatus) => {
    setReservations(prev => prev.map(r => r.id === resId ? { ...r, status: newStatus } : r));
  };
  
  const addMenuItem = (item) => {
    setMenuItems(prev => [...prev, { ...item, id: Date.now().toString() }]);
    Alert.alert('Success', 'Item added to menu');
  };
  
  const deleteMenuItem = (itemId) => {
    setMenuItems(prev => prev.filter(i => i.id !== itemId));
    Alert.alert('Success', 'Item deleted');
  };
  
  const updateOrderStatus = (orderId, newStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
  };

  return (
    <AppContext.Provider value={{
      user, loginAsCustomer, loginAsManager, logout,
      menuItems, addMenuItem, deleteMenuItem,
      cart, addToCart, removeFromCart, updateQuantity,
      orders, placeOrder, updateOrderStatus,
      reservations, addReservation, updateReservationStatus,
      currentScreen, setCurrentScreen,
      currentTab, setCurrentTab,
    }}>
      {children}
    </AppContext.Provider>
  );
};

const useApp = () => useContext(AppContext);

// ======================== LOGIN SCREEN ========================
const LoginScreen = () => {
  const { loginAsCustomer, loginAsManager } = useApp();
  const [name, setName] = useState('');
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      <View style={styles.loginContainer}>
        <Text style={styles.logo}>🍽️</Text>
        <Text style={styles.title}>Restaurant App</Text>
        <Text style={styles.subtitle}>Welcome! Please login to continue</Text>
        
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Customer Login</Text>
          <TextInput 
            style={styles.input} 
            placeholder="Enter your name" 
            value={name} 
            onChangeText={setName}
          />
          <TouchableOpacity 
            style={styles.customerBtn} 
            onPress={() => {
              if (name.trim()) {
                loginAsCustomer(name);
              } else {
                Alert.alert('Error', 'Please enter your name');
              }
            }}>
            <Text style={styles.btnText}>Continue as Customer</Text>
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity style={styles.managerBtn} onPress={() => loginAsManager()}>
          <Text style={styles.btnText}>Login as Manager</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

// ======================== CUSTOMER SCREENS ========================
const MenuScreen = () => {
  const { menuItems, addToCart } = useApp();
  
  const renderItem = ({ item }) => (
    <View style={styles.menuCard}>
      <Text style={styles.menuImage}>{item.image}</Text>
      <View style={styles.menuInfo}>
        <Text style={styles.menuName}>{item.name}</Text>
        <Text style={styles.menuDesc}>{item.description}</Text>
        <Text style={styles.menuPrice}>Rs. {item.price}</Text>
      </View>
      <TouchableOpacity style={styles.addButton} onPress={() => addToCart(item)}>
        <Text style={styles.addButtonText}>+</Text>
      </TouchableOpacity>
    </View>
  );
  
  return (
    <View style={styles.screen}>
      <Text style={styles.screenTitle}>🍕 Our Menu</Text>
      <FlatList data={menuItems} renderItem={renderItem} keyExtractor={item => item.id} showsVerticalScrollIndicator={false} />
    </View>
  );
};

const CartScreen = () => {
  const { cart, updateQuantity, removeFromCart, setCurrentTab } = useApp();
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  
  if (cart.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyIcon}>🛒</Text>
        <Text style={styles.emptyText}>Your cart is empty</Text>
        <TouchableOpacity style={styles.shopButton} onPress={() => setCurrentTab('menu')}>
          <Text style={styles.btnText}>Start Shopping</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  const renderItem = ({ item }) => (
    <View style={styles.cartCard}>
      <View style={styles.cartInfo}>
        <Text style={styles.cartName}>{item.name}</Text>
        <Text style={styles.cartPrice}>Rs. {item.price}</Text>
      </View>
      <View style={styles.cartActions}>
        <TouchableOpacity onPress={() => updateQuantity(item.id, item.quantity - 1)}>
          <Text style={styles.qtyButton}>-</Text>
        </TouchableOpacity>
        <Text style={styles.qtyText}>{item.quantity}</Text>
        <TouchableOpacity onPress={() => updateQuantity(item.id, item.quantity + 1)}>
          <Text style={styles.qtyButton}>+</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => removeFromCart(item.id)}>
          <Text style={styles.removeButton}>Remove</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.itemTotal}>Rs. {(item.price * item.quantity).toFixed(2)}</Text>
    </View>
  );
  
  return (
    <View style={styles.screen}>
      <Text style={styles.screenTitle}>🛒 Your Cart</Text>
      <FlatList data={cart} renderItem={renderItem} keyExtractor={item => item.id} />
      <View style={styles.totalContainer}>
        <Text style={styles.totalText}>Total: Rs. {total.toFixed(2)}</Text>
        <TouchableOpacity style={styles.checkoutButton} onPress={() => setCurrentTab('checkout')}>
          <Text style={styles.btnText}>Proceed to Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const CheckoutScreen = () => {
  const { cart, placeOrder, setCurrentTab } = useApp();
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  
  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.screenTitle}>💰 Checkout</Text>
      
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Order Summary</Text>
        {cart.map(item => (
          <View key={item.id} style={styles.summaryRow}>
            <Text>{item.name} x{item.quantity}</Text>
            <Text>Rs. {(item.price * item.quantity).toFixed(2)}</Text>
          </View>
        ))}
        <View style={styles.divider} />
        <View style={styles.summaryTotal}>
          <Text style={styles.totalLabel}>Total:</Text>
          <Text style={styles.totalAmount}>Rs. {total.toFixed(2)}</Text>
        </View>
      </View>
      
      <View style={styles.paymentCard}>
        <Text style={styles.paymentTitle}>Payment Method</Text>
        <Text style={styles.paymentText}>💳 Credit Card (Demo)</Text>
      </View>
      
      <TouchableOpacity style={styles.placeOrderButton} onPress={() => { placeOrder(); setCurrentTab('menu'); }}>
        <Text style={styles.btnText}>Place Order</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const ReservationScreen = () => {
  const { reservations, addReservation, user } = useApp();
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [guests, setGuests] = useState('');
  const [requests, setRequests] = useState('');
  
  const handleBook = () => {
    if (date && time && guests) {
      addReservation({ date, time, guests: parseInt(guests), requests });
      setDate('');
      setTime('');
      setGuests('');
      setRequests('');
    } else {
      Alert.alert('Error', 'Please fill all fields');
    }
  };
  
  const userReservations = reservations.filter(r => r.customerName === user.name);
  
  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.screenTitle}>📅 Table Reservation</Text>
      
      <View style={styles.formCard}>
        <Text style={styles.formTitle}>Book a Table</Text>
        <TextInput style={styles.input} placeholder="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} />
        <TextInput style={styles.input} placeholder="Time (HH:MM)" value={time} onChangeText={setTime} />
        <TextInput style={styles.input} placeholder="Number of guests" value={guests} onChangeText={setGuests} keyboardType="numeric" />
        <TextInput style={styles.input} placeholder="Special requests" value={requests} onChangeText={setRequests} multiline />
        <TouchableOpacity style={styles.bookButton} onPress={handleBook}>
          <Text style={styles.btnText}>Book Table</Text>
        </TouchableOpacity>
      </View>
      
      <Text style={styles.sectionTitle}>Your Reservations</Text>
      {userReservations.length === 0 ? (
        <Text style={styles.noData}>No reservations yet</Text>
      ) : (
        userReservations.map(res => (
          <View key={res.id} style={styles.resCard}>
            <Text style={styles.resDate}>📅 {res.date} at {res.time}</Text>
            <Text>👥 {res.guests} guests</Text>
            <Text style={[styles.resStatus, res.status === 'Confirmed' && styles.statusConfirmed]}>Status: {res.status}</Text>
            {res.requests ? <Text>📝 {res.requests}</Text> : null}
          </View>
        ))
      )}
    </ScrollView>
  );
};

const ProfileScreen = () => {
  const { user, logout } = useApp();
  
  return (
    <View style={styles.profileContainer}>
      <Text style={styles.profileIcon}>👤</Text>
      <Text style={styles.profileName}>{user?.name}</Text>
      <Text style={styles.profileEmail}>{user?.email}</Text>
      <TouchableOpacity style={styles.logoutButton} onPress={logout}>
        <Text style={styles.btnText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

// ======================== MANAGER SCREENS ========================
const DashboardScreen = () => {
  const { menuItems, orders, reservations } = useApp();
  
  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.screenTitle}>📊 Dashboard</Text>
      
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>🍕</Text>
          <Text style={styles.statNumber}>{menuItems.length}</Text>
          <Text style={styles.statLabel}>Menu Items</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>📦</Text>
          <Text style={styles.statNumber}>{orders.length}</Text>
          <Text style={styles.statLabel}>Total Orders</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>📅</Text>
          <Text style={styles.statNumber}>{reservations.length}</Text>
          <Text style={styles.statLabel}>Reservations</Text>
        </View>
      </View>
    </ScrollView>
  );
};

const ManageMenuScreen = () => {
  const { menuItems, deleteMenuItem, addMenuItem } = useApp();
  const [newItem, setNewItem] = useState({ name: '', price: '', description: '', image: '🍽️' });
  
  const handleAdd = () => {
    if (newItem.name && newItem.price) {
      addMenuItem({ ...newItem, price: parseFloat(newItem.price) });
      setNewItem({ name: '', price: '', description: '', image: '🍽️' });
    } else {
      Alert.alert('Error', 'Please enter name and price');
    }
  };
  
  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.screenTitle}>🍔 Manage Menu</Text>
      
      <View style={styles.formCard}>
        <Text style={styles.formTitle}>Add New Item</Text>
        <TextInput style={styles.input} placeholder="Item Name" value={newItem.name} onChangeText={t => setNewItem({ ...newItem, name: t })} />
        <TextInput style={styles.input} placeholder="Price (PKR)" value={newItem.price} onChangeText={t => setNewItem({ ...newItem, price: t })} keyboardType="numeric" />
        <TextInput style={styles.input} placeholder="Description" value={newItem.description} onChangeText={t => setNewItem({ ...newItem, description: t })} />
        <TouchableOpacity style={styles.addItemButton} onPress={handleAdd}>
          <Text style={styles.btnText}>Add to Menu</Text>
        </TouchableOpacity>
      </View>
      
      <Text style={styles.sectionTitle}>Current Menu</Text>
      {menuItems.map(item => (
        <View key={item.id} style={styles.menuManageCard}>
          <View>
            <Text style={styles.menuManageName}>{item.image} {item.name}</Text>
            <Text style={styles.menuManagePrice}>Rs. {item.price}</Text>
          </View>
          <TouchableOpacity onPress={() => deleteMenuItem(item.id)}>
            <Text style={styles.deleteButton}>Delete</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
};

const OrdersScreen = () => {
  const { orders, updateOrderStatus } = useApp();
  
  if (orders.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyIcon}>📦</Text>
        <Text style={styles.emptyText}>No orders yet</Text>
      </View>
    );
  }
  
  return (
    <FlatList 
      style={styles.screen}
      data={orders} 
      keyExtractor={item => item.id} 
      renderItem={({ item }) => (
        <View style={styles.orderCard}>
          <Text style={styles.orderId}>Order #{item.id.slice(-6)}</Text>
          <Text>Customer: {item.customerName}</Text>
          <Text>Items: {item.items.length}</Text>
          <Text>Total: Rs. {item.total}</Text>
          <Text>Date: {item.date}</Text>
          <Text style={styles.orderStatus}>Status: {item.status}</Text>
          <View style={styles.statusButtons}>
            {['Received', 'Preparing', 'Completed'].map(status => (
              <TouchableOpacity key={status} style={[styles.statusButton, item.status === status && styles.activeStatus]} onPress={() => updateOrderStatus(item.id, status)}>
                <Text style={item.status === status && styles.activeText}>{status}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )} 
    />
  );
};

const ManageReservationsScreen = () => {
  const { reservations, updateReservationStatus } = useApp();
  
  if (reservations.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyIcon}>📅</Text>
        <Text style={styles.emptyText}>No reservations yet</Text>
      </View>
    );
  }
  
  return (
    <FlatList 
      style={styles.screen}
      data={reservations} 
      keyExtractor={item => item.id} 
      renderItem={({ item }) => (
        <View style={styles.resCard}>
          <Text style={styles.resCustomer}>👤 {item.customerName}</Text>
          <Text>📅 Date: {item.date}</Text>
          <Text>⏰ Time: {item.time}</Text>
          <Text>👥 Guests: {item.guests}</Text>
          <Text>Status: {item.status}</Text>
          <View style={styles.statusButtons}>
            {['Pending', 'Confirmed', 'Completed', 'Cancelled'].map(status => (
              <TouchableOpacity key={status} style={[styles.statusButton, item.status === status && styles.activeStatus]} onPress={() => updateReservationStatus(item.id, status)}>
                <Text style={item.status === status && styles.activeText}>{status}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )} 
    />
  );
};

const ManagerProfileScreen = () => {
  const { user, logout } = useApp();
  
  return (
    <View style={styles.profileContainer}>
      <Text style={styles.profileIcon}>👨‍💼</Text>
      <Text style={styles.profileName}>{user?.name}</Text>
      <Text style={styles.profileEmail}>{user?.email}</Text>
      <TouchableOpacity style={styles.logoutButton} onPress={logout}>
        <Text style={styles.btnText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

// ======================== TAB BAR ========================
const TabBar = ({ tabs, activeTab, onTabPress }) => {
  return (
    <View style={styles.tabBar}>
      {tabs.map(tab => (
        <TouchableOpacity key={tab.id} style={[styles.tabItem, activeTab === tab.id && styles.activeTab]} onPress={() => onTabPress(tab.id)}>
          <Text style={styles.tabIcon}>{tab.icon}</Text>
          <Text style={[styles.tabLabel, activeTab === tab.id && styles.activeTabLabel]}>{tab.name}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

// ======================== MAIN APPS ========================
const CustomerApp = () => {
  const { currentTab, setCurrentTab } = useApp();
  
  const tabs = [
    { id: 'menu', name: 'Menu', icon: '🍕', component: MenuScreen },
    { id: 'cart', name: 'Cart', icon: '🛒', component: CartScreen },
    { id: 'reserve', name: 'Reserve', icon: '📅', component: ReservationScreen },
    { id: 'profile', name: 'Profile', icon: '👤', component: ProfileScreen },
  ];
  
  if (currentTab === 'checkout') {
    return (
      <View style={{ flex: 1 }}>
        <CheckoutScreen />
        <TouchableOpacity style={styles.backButton} onPress={() => setCurrentTab('cart')}>
          <Text style={styles.backButtonText}>← Back to Cart</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  const CurrentComponent = tabs.find(tab => tab.id === currentTab)?.component;
  
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#f8f9fa' }}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      <CurrentComponent />
      <TabBar tabs={tabs} activeTab={currentTab} onTabPress={setCurrentTab} />
    </SafeAreaView>
  );
};

const ManagerApp = () => {
  const { currentTab, setCurrentTab } = useApp();
  
  const tabs = [
    { id: 'dashboard', name: 'Home', icon: '📊', component: DashboardScreen },
    { id: 'menu', name: 'Menu', icon: '🍔', component: ManageMenuScreen },
    { id: 'orders', name: 'Orders', icon: '📦', component: OrdersScreen },
    { id: 'reservations', name: 'Reserve', icon: '📅', component: ManageReservationsScreen },
    { id: 'profile', name: 'Profile', icon: '👤', component: ManagerProfileScreen },
  ];
  
  const CurrentComponent = tabs.find(tab => tab.id === currentTab)?.component;
  
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#f8f9fa' }}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      <CurrentComponent />
      <TabBar tabs={tabs} activeTab={currentTab} onTabPress={setCurrentTab} />
    </SafeAreaView>
  );
};

// ======================== MAIN APP ========================
const MainApp = () => {
  const { currentScreen } = useApp();
  
  if (currentScreen === 'login') return <LoginScreen />;
  if (currentScreen === 'customer') return <CustomerApp />;
  if (currentScreen === 'manager') return <ManagerApp />;
  return <LoginScreen />;
};

// ======================== EXPORT ========================
export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}

// ======================== STYLES ========================
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  loginContainer: { flex: 1, justifyContent: 'center', padding: 20 },
  logo: { fontSize: 60, textAlign: 'center', marginBottom: 10 },
  title: { fontSize: 32, fontWeight: 'bold', textAlign: 'center', color: '#e67e22', marginBottom: 8 },
  subtitle: { fontSize: 14, textAlign: 'center', color: '#666', marginBottom: 40 },
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 20, marginBottom: 20, elevation: 3 },
  cardTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12, color: '#2c3e50' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, fontSize: 16, marginBottom: 12, backgroundColor: '#fff' },
  customerBtn: { backgroundColor: '#e67e22', padding: 14, borderRadius: 8, alignItems: 'center' },
  managerBtn: { backgroundColor: '#2c3e50', padding: 14, borderRadius: 8, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  screen: { flex: 1, padding: 16, backgroundColor: '#f8f9fa' },
  screenTitle: { fontSize: 28, fontWeight: 'bold', marginBottom: 16, color: '#2c3e50' },
  sectionTitle: { fontSize: 20, fontWeight: 'bold', marginTop: 20, marginBottom: 12, color: '#2c3e50' },
  menuCard: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 12, padding: 12, marginBottom: 12, alignItems: 'center', elevation: 2 },
  menuImage: { fontSize: 40, marginRight: 12 },
  menuInfo: { flex: 1 },
  menuName: { fontSize: 18, fontWeight: 'bold' },
  menuDesc: { color: '#666', marginVertical: 4 },
  menuPrice: { fontWeight: '600', color: '#e67e22', fontSize: 16 },
  addButton: { backgroundColor: '#e67e22', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  addButtonText: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  emptyIcon: { fontSize: 64, marginBottom: 16 },
  emptyText: { fontSize: 18, color: '#888', marginBottom: 20 },
  shopButton: { backgroundColor: '#e67e22', padding: 12, borderRadius: 8 },
  cartCard: { backgroundColor: '#fff', padding: 12, marginVertical: 6, borderRadius: 8, elevation: 1 },
  cartInfo: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  cartName: { fontSize: 16, fontWeight: 'bold' },
  cartPrice: { color: '#e67e22', fontWeight: 'bold' },
  cartActions: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  qtyButton: { fontSize: 20, paddingHorizontal: 12, paddingVertical: 4, backgroundColor: '#f0f0f0', borderRadius: 4, marginRight: 8, fontWeight: 'bold' },
  qtyText: { fontSize: 16, marginHorizontal: 10 },
  removeButton: { color: 'red', marginLeft: 20 },
  itemTotal: { marginTop: 8, fontWeight: 'bold', textAlign: 'right' },
  totalContainer: { padding: 16, borderTopWidth: 1, borderColor: '#ddd', backgroundColor: '#fff', marginTop: 16 },
  totalText: { fontSize: 20, fontWeight: 'bold', marginBottom: 12 },
  checkoutButton: { backgroundColor: '#e67e22', padding: 14, borderRadius: 8, alignItems: 'center' },
  summaryCard: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 16 },
  summaryTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 },
  divider: { height: 1, backgroundColor: '#e0e0e0', marginVertical: 12 },
  summaryTotal: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  totalLabel: { fontSize: 18, fontWeight: 'bold' },
  totalAmount: { fontSize: 18, fontWeight: 'bold', color: '#e67e22' },
  paymentCard: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 16 },
  paymentTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 12 },
  paymentText: { padding: 12, backgroundColor: '#f8f9fa', borderRadius: 8 },
  placeOrderButton: { backgroundColor: '#27ae60', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 16 },
  formCard: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 16 },
  formTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  bookButton: { backgroundColor: '#e67e22', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  addItemButton: { backgroundColor: '#27ae60', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  resCard: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 8, elevation: 1 },
  resDate: { fontWeight: 'bold', marginBottom: 4 },
  resStatus: { marginTop: 4, fontWeight: '500', color: '#e67e22' },
  statusConfirmed: { color: '#27ae60' },
  resCustomer: { fontWeight: 'bold', fontSize: 16, marginBottom: 4 },
  noData: { textAlign: 'center', color: '#888', padding: 20 },
  profileContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  profileIcon: { fontSize: 80, marginBottom: 16 },
  profileName: { fontSize: 26, fontWeight: 'bold', marginBottom: 8 },
  profileEmail: { fontSize: 16, color: '#666', marginBottom: 30 },
  logoutButton: { backgroundColor: '#c0392b', padding: 12, borderRadius: 8, width: '80%', alignItems: 'center' },
  statsContainer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 20 },
  statCard: { backgroundColor: '#fff', borderRadius: 12, padding: 20, alignItems: 'center', width: '31%', elevation: 2 },
  statIcon: { fontSize: 32, marginBottom: 8 },
  statNumber: { fontSize: 24, fontWeight: 'bold', color: '#e67e22' },
  statLabel: { fontSize: 12, color: '#666', marginTop: 4 },
  menuManageCard: { backgroundColor: '#fff', padding: 12, marginBottom: 8, borderRadius: 8, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', elevation: 1 },
  menuManageName: { fontSize: 16, fontWeight: 'bold' },
  menuManagePrice: { color: '#e67e22', marginTop: 4 },
  deleteButton: { color: 'red', fontWeight: 'bold' },
  orderCard: { backgroundColor: '#fff', padding: 12, marginBottom: 12, borderRadius: 8, elevation: 1 },
  orderId: { fontWeight: 'bold', fontSize: 16, marginBottom: 8 },
  orderStatus: { marginTop: 8, fontWeight: 'bold' },
  statusButtons: { flexDirection: 'row', marginTop: 8, flexWrap: 'wrap' },
  statusButton: { backgroundColor: '#ecf0f1', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, marginRight: 8, marginBottom: 4 },
  activeStatus: { backgroundColor: '#e67e22' },
  activeText: { color: '#fff' },
  backButton: { padding: 12, backgroundColor: '#e67e22', alignItems: 'center' },
  backButtonText: { color: '#fff', fontWeight: 'bold' },
  tabBar: { flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderColor: '#ddd', paddingVertical: 8 },
  tabItem: { flex: 1, alignItems: 'center', paddingVertical: 8 },
  activeTab: { backgroundColor: '#f0f0f0', borderRadius: 8 },
  tabIcon: { fontSize: 24 },
  tabLabel: { fontSize: 12, marginTop: 4, color: '#666' },
  activeTabLabel: { color: '#e67e22', fontWeight: 'bold' },
});
